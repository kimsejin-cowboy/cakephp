<?php
/**
 * 新規追加画面
 */
/* TODO 6/1-2 検索画面と同じデザインで表示されるようにしてください */
/* TODO 6/1-2 地方公共団体以外のフィールドの入力フィールドを入力する要素を追加してください */
/* ただし、id、old_postal_code、created、modifiedは追加しなくて良いものとします */
/* prefecture_idはprefecturesテーブルから都道府県のリストを取得し、セレクトボックスで表示してください */
/* TODO 6/1-2 データがPOSTされた場合のみ、テーブルpostal_codesに新しい郵便番号データを追加（INSERT）する機能を実装してください */
/* TODO 6/1-2 INSERTする前にバリデーションを実装してください */
/***************************************************/
/* バリデーションルール                                */
/* local_goverment_code                半角数字６けた */
/* postal_codes                        半角数字７けた */
/* city_name       マルチバイト２５６文字以内、空文字はダメ */
/* address         マルチバイト２５６文字以内、空文字はダメ */
/****************************************************/
/* 残りのフィールド */
/* old_postal_codes バリデーションを通過した場合のみ、 postal_codesの先頭５文字を切り取ったものを取得してください */
/* バリデーションを通過できなかった場合は、その理由を例にならって表示してください */
/* created, modified 現在日時を取得してください */
/* 6/1-2 TODO INSERTが成功した場合、INSERTしたデータのidを取得し、/raw_php/postal_codes/edit.php?id=取得したidにリダイレクトしてください */
/* 以下実装例 */

$conn = mysql_connect('localhost', 'tutorial', 'tutorial');
// 文字コードセット
mysql_set_charset('utf8', $conn);
// database 選択
mysql_select_db('tutorial', $conn);
// 都道府県リスト格納用変数
$prefecture_list = array();
// 都道府県リスト取得用sql
$sql = 'SELECT `id`, `prefecture_name` FROM `prefectures` ORDER BY `id` ASC';
// query 実行
$result = mysql_query($sql, $conn);
while ($row = mysql_fetch_assoc($result)) {
	$prefecture_list[] = $row;
}

// $_GETの中身
// var_dump($_GET);
// query string 取得
$prefecture_id = null;// 都道府県ID
if (isset($_GET['prefecture_id'])) {
	$prefecture_id = $_GET['prefecture_id'];
}



//var

$local_goverment_code = '';// 地方公共団体コード

// バリデーションエラー格納用変数
$validation_errors = array();
// $_POSTが空でなければ
if (!empty($_POST)) {
    // POSTされた値を取得
    if (isset($_POST['local_goverment_code'])) {
        $local_goverment_code = $_POST['local_goverment_code'];
    }

    // バリデーション
    if (!is_numeric($local_goverment_code) || strlen($local_goverment_code) != 6) {
        $validation_errors['local_goverment_code'] = '地方公共団体コードは半角数字６桁で入力してください';
    }


    // INSERT


    // リダイレクト


}

?>
<!DOCTYPE html>
<html>
     <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>PostalCodes</title>
        <link rel="stylesheet" type="text/css" href="/raw_php/css/cake.generic.css" />
        <link rel="stylesheet" type="text/css" href="/raw_php/css/jquery-ui.css" />
        <link rel="stylesheet" type="text/css" href="/raw_php/css/jquery-ui.structure.css" />
        <link rel="stylesheet" type="text/css" href="/raw_php/css/jquery-ui.theme.css" />
        <link rel="stylesheet" type="text/css" href="/raw_php/css/tutorial.css" />
        <script type="text/javascript" src="/raw_php/js/jquery.js"></script>
        <script type="text/javascript" src="/raw_php/js/jquery.ui.js"></script>
        <script type="text/javascript" src="/raw_php/js/tutorial.js"></script>
    </head>
    <body>
    <div id="container">
            <div id="header">Turorial</div>
            <div id="content">
                <div id="postal-code-search-form">
        <!-- CRUD操作のうち、CUDはPOSTで行うのが基本です -->
        <!-- データ更新用のフォームのmethodは、POSTを使いましょう -->
        <form method="post" action="/raw_php/postal_codes/add.php" id="PostalCodeSearchForm" accept-charset="utf-8">
            <table>
                <tr>
                    <td>地方公共団体コード</td>
                    <td>
                        <input type="text" name="local_goverment_code" value="<?php echo $local_goverment_code; ?>">
                        <?php /* バリデーションエラー表示例 */ ?>
                        <?php if (!empty($validation_errors['local_goverment_code'])) { ?>
                        <div class="error-message"><?php echo $validation_errors['local_goverment_code']; ?></div>
                        <?php } ?>
                    </td>
                </tr>
                 <tr>
                 <td>都道府県</td>
                                <td>
                                    <select name="prefecture_id" id="PostalCodePrefectureId">
                                    <?php for ($i = 0; $i < count($prefecture_list); $i++) { ?>
                                        <option value="<?php echo $prefecture_list[$i]['id']; ?>"<?php if ($prefecture_id == $prefecture_list[$i]['id']) { echo 'selected="selected"';} ?>>
                                        <?php echo $prefecture_list[$i]['prefecture_name']; ?></option>
                                    <?php } ?>
                                    </select>
                                </td>
                                </tr>
                                <tr>

                                <td>郵便番号</td>
                                <td>
                                    <input type="text" name="postal_code"  />
                                </td>
                            </tr>

                            <tr>
                                <td>地区長村</td>
                                <td>
                                    <input type="text" name="city_name" />
                                </td>
                            </tr>

                            <tr>
                                <td>町域</td>
                                <td>
                                    <input type="text" name="address" />
                                </td>
                            </tr>


            </table>
            <input name="add" type="submit" value="追加"/>
        </form>
        </div>
    </div>
    </div>
    </body>


</html>
