<?php
/**
 * 削除処理
 * このファイルは画面を持ちません
 */
/* TODO 6/3 データがPOSTされた場合のみ、idを取得し、データを削除（DELETE）してください */
/* TODO 6/3 POSTされてもidが取得できなかった場合、検索画面へリダイレクトしてください */
/* TODO 6/3 DELETEの成功・失敗に関わらず、処理が終わったら検索画面へリダイレクトしてください */
$conn = mysql_connect('localhost', 'tutorial', 'tutorial');
// 文字コードセット
mysql_set_charset('utf8', $conn);
// database 選択
mysql_select_db('tutorial', $conn);
$before_url = '/raw_php/postal_codes/search.php';
if (isset($_POST['id'])) {
	$id = $_POST['id'];

	//$sql = 'DELETE FROM tutorial.postal_codes WHERE id='.$id;
	$sql = 'DELETE FROM `tutorial`.`postal_codes` WHERE `postal_codes`.`id` ='.$id;


	$result = mysql_query($sql, $conn);
//	$_SERVER["HTTP_REFERER"];

	header('Location:./add_kim.php');
	exit();
} else {
	header('Location:./add_kim.php');
	exit();
}

//var_dump($_POST);
